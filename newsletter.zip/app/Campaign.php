<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Helpers\GetSelected;
use App\Helpers\Selectable;

class Campaign extends Model
{
	use SoftDeletes, Selectable, GetSelected;
  
    protected $fillable = ['name', 'descr'];

    public function bunches()
    {
       return $this->hasMany(Bunch::class);
    }

    public function template()
    {
       return $this->hasOne(Template::class);
    }
}
