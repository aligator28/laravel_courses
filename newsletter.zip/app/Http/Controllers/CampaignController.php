<?php

namespace App\Http\Controllers;

use App\Campaign;
use Illuminate\Http\Request;
use App\Http\Requests\CampaignRequest;
use App\Bunch;
use App\Template;

class CampaignController extends Controller
{
    /**
     * 
     * У Кампании может быть много банчей, но один и тот же банч не может принадлежать разным кампаниям
     */
    
    private $view_folder = 'campaign';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $items = Campaign::get();

        return view($this->view_folder.'.index', compact('items'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Bunch $bunch, Template $template)
    {
        $bunches = $bunch->getSelectList();
        $templates = $template->getSelectList();

        // just to select first element in multiple select list
        $selected_bunches = [1];
        $selected_templates = [1];
        return view($this->view_folder.'.create', compact(['bunches', 'templates', 'selected_bunches', 'selected_templates']) );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Campaign $campaign, Bunch $bunch, Template $template, CampaignRequest $request)
    {
        // just create campaign (table do not have fields bunch_id and template_id)
        $inserted_campaign = $campaign
            ->create( $request->except( ['bunch_ids', 'template_ids'] ) );

        $campaign
            ->findOrFail($inserted_campaign->id)   
            ->bunches()
            ->saveMany( $bunch->find($request->bunch_ids) );

          
        $campaign
            ->findOrFail($inserted_campaign->id)
            ->template()
            ->save( $template->find($request->template_ids) );


        return redirect()->route($this->view_folder . '.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Campaign  $item
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = Campaign::findOrFail($id);
        return view($this->view_folder . '.show', compact('item'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Campaign  $item
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $item = Campaign::findOrFail($id);//with(['bunches', 'templates'])->
        
        $bunches = Bunch::getSelectList();
        $templates = Template::getSelectList();

        $selected_bunches = Campaign::selected($id, 'bunches', $bunches, 'name');
        $selected_templates = Campaign::selected($id, 'templates', $templates, 'name');

        return view($this->view_folder.'.edit', compact( ['item', 'bunches', 'templates' , 'selected_bunches', 'selected_templates'] ));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Campaign  $item
     * @return \Illuminate\Http\Response
     */
    public function update(CampaignRequest $request, Bunch $bunch, Template $template, Campaign $item, $id)
    {
        $item->update( $request->except( ['bunch_ids', 'template_ids'] ) );

        // dd($inserted_campaign);

        $item
            ->findOrFail($id)   
            ->bunches()
            ->saveMany( $bunch->find($request->bunch_ids) );

          
        $item
            ->findOrFail($id)
            ->template()
            ->save( $template->find($request->template_ids) );



        // $item->findOrFail($id)->update($request->all());
        return redirect()->route( $this->view_folder . '.index' );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Campaign  $item
     * @return \Illuminate\Http\Response
     */
    public function destroy(Campaign $campaign)
    {
        $campaign->delete();
        return redirect()->route($this->view_folder . '.index');
    }
}
