<div class="form-group">
 {!!Form::label('name', 'Name') !!}
 {!!Form::text('name', null, ['class' => 'form-control', 'required', 'minlength' => '5']) !!}
</div>

<div class="form-group">
{!!Form::label('bunch_id', 'Bunches') !!}
 {!! Form::select( 'bunch_ids[]', $bunches, $selected_bunches, ['class' => 'form-control', 'multiple'] ) !!}
</div>

<div class="form-group">
{!!Form::label('template_id', 'Templates') !!}
 {!! Form::select( 'template_ids[]', $templates, $selected_templates, ['class' => 'form-control'] ) !!}
</div>

<div class="form-group"> 
 {!!Form::label('descr', 'Description') !!}
 {!!Form::textarea('descr', null, ['class' => 'form-control', 'required', 'minlength' => '5']) !!}
</div>