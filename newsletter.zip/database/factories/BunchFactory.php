<?php

use Faker\Generator as Faker;

$factory->define(App\Bunch::class, function (Faker $faker) {
    return [
        //
    ];
});
